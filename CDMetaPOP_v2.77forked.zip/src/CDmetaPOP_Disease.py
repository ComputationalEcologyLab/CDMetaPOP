# -------------------------------------------------------------------------------------------------
# CDmetaPOP_Disease.py
# Author: Erin L Landguth
# Created: December 2024
# Description: This is the function/module file for Disease processes.
# --------------------------------------------------------------------------------------------------
	
# Python specific functions
import os, copy, pdb, sys
import numpy as np
import pandas as pd
#from CDmetaPOP_Modules import validate # circular import somewhere 

# ---------------------------------------------------------------------------
def validate(condition, error_message, exit_code=-1):
    """
    Generic error-checking function.

    Args:
        condition (bool): The condition to evaluate.
        error_message (str): The error message to display if the condition fails.
        exit_code (int): The code to exit with if the condition fails. Default is -1.
    """
    if condition:
        print(error_message)
        sys.exit(exit_code)
	
	# End::validate()

# ---------------------------------------------------------------------------
def read_disease_vars_files(filelist, datadir):    
	''' Helper function to read in DiseaseVars file'''
	noStates,InitCond,TranRates,TranRatesSD = [],[],[],[]
	for ifile in range(len(filelist)):
		# Read the CSV file into a pandas DataFrame
		df = pd.read_csv(datadir+filelist[ifile], header=None)
		noStates.append(int(df.iloc[1,0]))
		InitCond.append(np.asarray(df.iloc[1,1].split(';'),float))
		TranRates.append(np.asarray(df.iloc[1,2].split(';'),float))
		TranRatesSD.append(np.asarray(df.iloc[1,3].split(';'),float))
		# Error Checks
		validate(noStates[ifile] != len(InitCond[ifile]), 'Number of Disease States must equal Initial Conditions.')
		validate(len(TranRates[ifile]) != noStates[ifile]-1, 'Number of disease transition rates must equal 1 less than number of disease states')
		validate(sum(InitCond[ifile]) != 1.0, 'Initial conditions for disease states must sum to 1.')
		validate(len(TranRates[ifile]) != len(TranRatesSD[ifile]), 'Number of disease transition rates and standard deviations must be equal.')
	tupDiseaseVars = noStates,InitCond,TranRates,TranRatesSD
	return tupDiseaseVars
	#End::read_disease_rate_files()

# ---------------------------------------------------------------------------
def infInd(SubpopIN,isub,iind,countstates_inthispatch,diseaserates_inthispatch,noStates):
	'''
	Update the disease state for each individual
	'''
	
	# Get Force of Infection = rate * proportion of infected individuals
	if sum(countstates_inthispatch) == 0:
		Force_ofInfection = 0.0
	# Assume first transmission rate and second state involved in transmission
	else: 
		Force_ofInfection = countstates_inthispatch[0]*diseaserates_inthispatch[0] / sum(countstates_inthispatch)
	
	# Update Susceptible state: assume first state is susceptible and moves to the infection state
	S0TOS1_rand = np.random.uniform()
	if SubpopIN[isub][iind]['states'] == 0:
		if S0TOS1_rand <= Force_ofInfection:
			SubpopIN[isub][iind]['states'] = 1
	
	# Update remaining states: assume linear movement between states, i.e., no feedback loops
	else:		
		for istate in range(1,noStates-1):						
			transitionTOistate_rand = np.random.uniform()		
			if SubpopIN[isub][iind]['states'] == istate and transitionTOistate_rand <= diseaserates_inthispatch[istate]:
				SubpopIN[isub][iind]['states'] = istate+1
				continue
	
# End::stateInd()

# ---------------------------------------------------------------------------
def test_patchlevel_diseasestates_update(gen,startdisease,gridsample,implementdisease,disease_vars,temp_tracking_eqn,SubpopIN_thissub,isub,countstates_inthispatch,noStates,diseaserates_inthispatch):
	'''
	This function is only for testing and getting the patch level state transitions
	In DoUpdate, after first Disease Process call in patch loop add:
	# Testing patch-level disease state updates
	#temp_tracking_eqn = [] -> this goes before patch loop
	#temp_tracking_eqn.append([])			#test_patchlevel_diseasestates_update(gen,startdisease,gridsample,implementdisease,disease_vars,temp_tracking_eqn,SubpopIN[isub],isub,countstates_inthispatch,noStates,diseaserates_inthispatch)
	'''
	
	if gen >= startdisease and ((gridsample == 'Middle' and implementdisease in ['Both','Back']) or (gridsample == 'Sample' and implementdisease in ['Both','Out'])):	
				
		if sum(countstates_inthispatch) == 0: # if population is 0 in this patch
			temp_tracking_eqn[isub].append(countstates_inthispatch)
									
		else:				
			'''
			# S to I: S*I*a/N
			StoI = countstates_inthispatch[0]*countstates_inthispatch[1]*diseaserates_inthispatch[0]/sum(countstates_inthispatch)
			# I to R: I*b - same idea
			ItoR = countstates_inthispatch[1]*diseaserates_inthispatch[1]
			
			# Then update next states
			Stplus1 = countstates_inthispatch[0] - round(StoI)
			Itplus1 = round(StoI)+countstates_inthispatch[1] - round(ItoR)
			Rtplus1 = countstates_inthispatch[2] + round(ItoR)
			temp_tracking_eqn[isub].append([Stplus1,Itplus1,Rtplus1])
			'''
			temp_xij_thatmove_eqn = []					
			# Generalized code of the above lines (for any number of states)
			for irate in range(len(diseaserates_inthispatch)):						
				
				# Get this transition rate
				thisRate = diseaserates_inthispatch[irate]
				
				# Assume first one is the transmission process
				if irate == 0: 
					SitoSj = countstates_inthispatch[irate]*countstates_inthispatch[irate+1]*thisRate/sum(countstates_inthispatch)
				else:
					SitoSj = thisRate*countstates_inthispatch[irate]
				
				temp_xij_thatmove_eqn.append(round(SitoSj))
								
			# Then update new disease state counts
			for istate in range(len(countstates_inthispatch)):						
				
				if istate == 0: # First State is the S*I*a/N
					thisStateChange = temp_xij_thatmove_eqn[istate]
					Stplus1 = countstates_inthispatch[istate] - thisStateChange
				
				elif istate == len(countstates_inthispatch)-1: # Last one					
					Stplus1 = returnthisStateChange + countstates_inthispatch[istate]
				
				else:
					thisStateChange = temp_xij_thatmove_eqn[istate]
					Stplus1 = returnthisStateChange + countstates_inthispatch[istate] - thisStateChange
					
				temp_tracking_eqn[isub].append(Stplus1)
				returnthisStateChange = thisStateChange
			
	else:
		temp_tracking_eqn[isub].append(countstates_inthispatch)
		
	#End::test_patchlevel_diseasestates_update()

# ---------------------------------------------------------------------------
def DoOut_AllTimeDiseasePatch(K_track,N_Init,Track_DiseaseStates_pop,Track_DiseaseStates_SecondUpdate,N_Emigration,N_EmiMortality, Track_DiseaseStates_ThirdUpdate,N_Immigration,N_ImmiMortality,ithmcrundir):
	'''Output tracking for Disease Counts'''
	
	# Create time array
	time = np.arange(0,len(K_track),1)
		
	# Get unique number of subpops -1 for total
	nosubpops = len(K_track[0])-1
	
	# Create file to write info to
	outputfile = open(ithmcrundir+'summary_popAllTime_DiseaseStates.csv','w')
	
	# Write out the titles
	# Add Titles from xypoints
	outputtitle = ['Year','N_Initial','States_GetMetrics','States_SecondUpdate','N_AfterEmigration','N_AfterEmiMort','States_ThirdUpdate','N_AfterImmigration','N_AfterImmiMort']
	
	# Write out the title
	for i in range(len(outputtitle)-1):
		outputfile.write(outputtitle[i]+',')
	# To get return character on the end
	outputfile.write(str(outputtitle[len(outputtitle)-1])+'\n')				
		
	# Write to file
	for i in range(len(time)-1):		
		outputfile.write(str(time[i])+',')
		for j in range(nosubpops+1):
			outputfile.write(str(N_Init[i][j])+'|')
		outputfile.write(',')
		
		for j in range(len(Track_DiseaseStates_pop[i])): # Subpop + 1
			for istate in range(len(Track_DiseaseStates_pop[i][j])): # Loop through states
				outputfile.write(str(Track_DiseaseStates_pop[i][j][istate]))
				if istate != len(Track_DiseaseStates_pop[i][j]) - 1:  # Add ';' if not the last element
					outputfile.write(';')
			outputfile.write('|')
		outputfile.write(',')
		
		for j in range(len(Track_DiseaseStates_SecondUpdate[i])): # Subpop + 1
			for istate in range(len(Track_DiseaseStates_SecondUpdate[i][j])): # Loop through states
				outputfile.write(str(Track_DiseaseStates_SecondUpdate[i][j][istate]))
				if istate != len(Track_DiseaseStates_SecondUpdate[i][j]) - 1:  # Add ';' if not the last element
					outputfile.write(';')
			outputfile.write('|')
		outputfile.write(',')
		
		for j in range(nosubpops+1):
			outputfile.write(str(N_Emigration[i][j])+'|')
		outputfile.write(',')
		
		for j in range(nosubpops+1):
			outputfile.write(str(N_EmiMortality[i][j])+'|')
		outputfile.write(',')
		
		for j in range(len(Track_DiseaseStates_ThirdUpdate[i])): # Subpop + 1
			for istate in range(len(Track_DiseaseStates_ThirdUpdate[i][j])): # Loop through states
				outputfile.write(str(Track_DiseaseStates_ThirdUpdate[i][j][istate]))
				if istate != len(Track_DiseaseStates_ThirdUpdate[i][j]) - 1:  # Add ';' if not the last element
					outputfile.write(';')
			outputfile.write('|')
		outputfile.write(',')
		
		for j in range(nosubpops+1):
			outputfile.write(str(N_Immigration[i][j])+'|')
		outputfile.write(',')				
					
		for j in range(nosubpops+1):
			outputfile.write(str(N_ImmiMortality[i][j])+'|')
		outputfile.write('\n')		
		
	# Logging message
	#stringout = 'The file summary_popAllTime_DiseaseStates.csv has been created'
	#logMsg(logfHndl,stringout)	
	
	# Close file
	outputfile.close()
	
	#End::DoOut_AllTimeDiseasePatch()



