# -------------------------------------------------------------------------------------------------
# CDmetaPOP_Disease.py
# Author: Erin L Landguth
# Created: December 2024
# Description: This is the function/module file for Disease processes.
# --------------------------------------------------------------------------------------------------
	
# Python specific functions
import os, copy, pdb, sys,random
import numpy as np
import pandas as pd
#from CDmetaPOP_Modules import validate # circular import somewhere 

# ---------------------------------------------------------------------------
def validate(condition, error_message, exit_code=-1):
    """
    Generic error-checking function.

    Args:
        condition (bool): The condition to evaluate.
        error_message (str): The error message to display if the condition fails.
        exit_code (int): The code to exit with if the condition fails. Default is -1.
    """
    if condition:
        print(error_message)
        sys.exit(exit_code)
	
	# End::validate()

# ---------------------------------------------------------------------------
def read_disease_vars_files(filelist, datadir,implementdisease):    
	''' Helper function to read in DiseaseVars file'''
	
	noStates,InitCond,TranRates_Files,infectCompartment,deathCompartment,offspringTransmissionAns,TranRates,ImplementWhen,StartDiseaseWhen,TranRates_copy = [],[],[],[],[],[],[],[],[],[]
	if implementdisease != 'N':
		for isub in range(len(filelist)):
			# Read the CSV file into a pandas DataFrame
			df = pd.read_csv(datadir+filelist[isub], header=None)
			noStates.append(int(df.iloc[1,0]))
			InitCond.append(np.asarray(df.iloc[1,1].split(';'),float).tolist())
			TranRates_Files.append(df.iloc[1,2])
			infectCompartment.append(df.iloc[1,3])
			deathCompartment.append(df.iloc[1,4])
			offspringTransmissionAns.append(df.iloc[1,5])
			StartDiseaseWhen.append(int(df.iloc[1,6]))
					
			# Read in Transition Matrix File
			df1 = pd.read_csv(datadir+TranRates_Files[isub],header=None)
			TranRates.append(np.asarray(df1,dtype=str).tolist())
			TranRates_copy.append(np.asarray(df1,dtype=str).tolist())
					
			# Error Checks
			validate(noStates[isub] != len(InitCond[isub]), 'Number of Disease States must equal Initial Conditions specified.')
			validate(sum(InitCond[isub]) != 1.0, 'Initial conditions for disease states must sum to 1.')		
			validate((len(TranRates[isub]) or len(TranRates[isub][0])) != noStates[isub], 'Transition matrix must be number of States x number of States')
			validate(offspringTransmissionAns[isub].lower() != 'susceptible', 'Incorrect option used for offspring transmission rules.')
			if deathCompartment[isub] != 'N':
				validate(noStates[isub] <= int(deathCompartment[isub]), 'Specific compartments (death) must be less than total number of states.')
			validate(noStates[isub] <= int(infectCompartment[isub]), 'Specific compartments (infect) must be less than total number of states.')

	else: # No disease, but initialize with one state
		noStates = [1 for x in range(len(filelist))]
	tupDiseaseVars = {'noStates':noStates,'InitCond':InitCond,'TransRates':TranRates,'InfComp':infectCompartment,'DComp':deathCompartment,'OffAns':offspringTransmissionAns, 'StartDisease': StartDiseaseWhen, 'TransRates_ForStochasticUpdates':TranRates_copy, 'ImpDisease':implementdisease}
	
	return tupDiseaseVars
	#End::read_disease_rate_files()

# ---------------------------------------------------------------------------
def moveStates(SubpopIN,isub,iind,countstates_inthispatch,disease_vars,gen):
	'''
	Update the disease state for each individual
	'''
	 
	# After burnin
	if gen >= disease_vars['StartDisease'][isub]:
		# Get Force of Infection = rate * proportion of infected individuals
		if sum(countstates_inthispatch) == 0: # No one in this patch
			Force_ofInfection = 0.0
		else: 
			# Update Susceptible state using Force of Infection: assume first state is susceptible and moves to the next state			
			if SubpopIN[isub][iind]['states'] == 0:
				
				# States that are susceptible: Assume first one
				susceptible_state = 0
				
				# Get the compartment(s) involved in infection - currently only 1 allowed
				infected_state = int(disease_vars['InfComp'][isub]) # index into infected state
									
				# Extract corresponding transmission rate from matrix [To this state][from this state]
				S_transmission_rate = disease_vars['TransRates'][isub][infected_state][susceptible_state]
				
				#Calculate force of infection as transmission rate * I / N
				Force_ofInfection = (countstates_inthispatch[infected_state] / sum(countstates_inthispatch)) * S_transmission_rate
				
				# Flip the coin to move this state or not
				willthisSusceptibleMove_randNO = np.random.uniform()
				if willthisSusceptibleMove_randNO <= Force_ofInfection:
					SubpopIN[isub][iind]['states'] = 1
			
			# Update remaining states: assume movement between states defined by transition matrix 
			else:		
				
				# This individuals state
				istate = SubpopIN[isub][iind]['states']	
					
				# Grab transition rates for this state (columns)
				thisStates_transmission_rates = [row[istate] for row in disease_vars['TransRates'][isub]]
					
				# Index values that this state could move to (non zero entries)
				moveTOIndex = np.where(np.asarray(thisStates_transmission_rates) > 0)[0]
				if len(moveTOIndex) != 0:					
					# Shuffle the moveTOIndex and loop through these possible moves
					random.shuffle(moveTOIndex)
					for imove in moveTOIndex:
						willthisStateMove_randNO = np.random.uniform()
						willthisStateMove_ToThisState = disease_vars['TransRates'][isub][imove][istate] 
						if willthisStateMove_randNO <= willthisStateMove_ToThisState:
							SubpopIN[isub][iind]['states'] = imove
							break # From inner loop					

	# End::moveStates()
	
# ---------------------------------------------------------------------------
def removeDStates(SubpopIN,isub,disease_vars,gen):
	'''
	Removes the dead individuals from each patch.
	'''
	
	keep_these_inds = np.where(SubpopIN[isub]['states'] != int(disease_vars['DComp'][isub]))[0]
	
	# Append all information to temp SubpopKeep variable
	SubpopIN[isub] = SubpopIN[isub][keep_these_inds]
	
	# End::removeDStates()

# ---------------------------------------------------------------------------
def test_patchlevel_diseasestates_update(gen,startdisease,gridsample,implementdisease,disease_vars,temp_tracking_eqn,SubpopIN_thissub,isub,countstates_inthispatch,noStates,diseaserates_inthispatch):
	'''
	This function is only for testing and getting the patch level state transitions
	In DoUpdate, after first Disease Process call in patch loop add:
	# Testing patch-level disease state updates
	#temp_tracking_eqn = [] -> this goes before patch loop
	#temp_tracking_eqn.append([])			#test_patchlevel_diseasestates_update(gen,startdisease,gridsample,implementdisease,disease_vars,temp_tracking_eqn,SubpopIN[isub],isub,countstates_inthispatch,noStates,diseaserates_inthispatch)
	'''
	
	if gen >= startdisease and ((gridsample == 'Middle' and implementdisease in ['Both','Back']) or (gridsample == 'Sample' and implementdisease in ['Both','Out'])):	
				
		if sum(countstates_inthispatch) == 0: # if population is 0 in this patch
			temp_tracking_eqn[isub].append(countstates_inthispatch)
									
		else:				
			'''
			# S to I: S*I*a/N
			StoI = countstates_inthispatch[0]*countstates_inthispatch[1]*diseaserates_inthispatch[0]/sum(countstates_inthispatch)
			# I to R: I*b - same idea
			ItoR = countstates_inthispatch[1]*diseaserates_inthispatch[1]
			
			# Then update next states
			Stplus1 = countstates_inthispatch[0] - round(StoI)
			Itplus1 = round(StoI)+countstates_inthispatch[1] - round(ItoR)
			Rtplus1 = countstates_inthispatch[2] + round(ItoR)
			temp_tracking_eqn[isub].append([Stplus1,Itplus1,Rtplus1])
			'''
			temp_xij_thatmove_eqn = []					
			# Generalized code of the above lines (for any number of states)
			for irate in range(len(diseaserates_inthispatch)):						
				
				# Get this transition rate
				thisRate = diseaserates_inthispatch[irate]
				
				# Assume first one is the transmission process
				if irate == 0: 
					SitoSj = countstates_inthispatch[irate]*countstates_inthispatch[irate+1]*thisRate/sum(countstates_inthispatch)
				else:
					SitoSj = thisRate*countstates_inthispatch[irate]
				
				temp_xij_thatmove_eqn.append(round(SitoSj))
								
			# Then update new disease state counts
			for istate in range(len(countstates_inthispatch)):						
				
				if istate == 0: # First State is the S*I*a/N
					thisStateChange = temp_xij_thatmove_eqn[istate]
					Stplus1 = countstates_inthispatch[istate] - thisStateChange
				
				elif istate == len(countstates_inthispatch)-1: # Last one					
					Stplus1 = returnthisStateChange + countstates_inthispatch[istate]
				
				else:
					thisStateChange = temp_xij_thatmove_eqn[istate]
					Stplus1 = returnthisStateChange + countstates_inthispatch[istate] - thisStateChange
					
				temp_tracking_eqn[isub].append(Stplus1)
				returnthisStateChange = thisStateChange
			
	else:
		temp_tracking_eqn[isub].append(countstates_inthispatch)
		
	#End::test_patchlevel_diseasestates_update()

# ---------------------------------------------------------------------------
def DoOut_AllTimeDiseasePatch(K_track,N_Init,Track_DiseaseStates_pop,Track_DiseaseStates_SecondUpdate,N_Emigration,N_EmiMortality, Track_DiseaseStates_ThirdUpdate,N_Immigration,N_ImmiMortality,ithmcrundir,Track_DiseaseStates_AddAge0s,Track_DiseaseStates_AddedInds,Track_DiseaseStates_AfterDeaths_SecondUpdate,Track_DiseaseStates_AfterDeaths_ThirdUpdate):
	'''Output tracking for Disease Counts'''
	
	# Create time array
	time = np.arange(0,len(K_track),1)
		
	# Get unique number of subpops -1 for total
	nosubpops = len(K_track[0])-1
	
	# Create file to write info to
	outputfile = open(ithmcrundir+'summary_popAllTime_DiseaseStates.csv','w')
	
	# Write out the titles
	# Add Titles from xypoints
	outputtitle = ['Year','N_Initial','States_GetMetrics','States_AfterAnyAddedInds','States_SecondUpdate','States_SecondUpdate_AfterDeathsRemoved','N_AfterEmigration','States_AddedAge0s','N_AfterEmiMort','States_ThirdUpdate','States_ThirdUpdate_AfterDeathsRemoved','N_AfterImmigration','N_AfterImmiMort']
	
	# Write out the title
	for i in range(len(outputtitle)-1):
		outputfile.write(outputtitle[i]+',')
	# To get return character on the end
	outputfile.write(str(outputtitle[len(outputtitle)-1])+'\n')				
		
	# Write to file
	for i in range(len(time)-1):		
		outputfile.write(str(time[i])+',')
		for j in range(nosubpops+1):
			outputfile.write(str(N_Init[i][j])+'|')
		outputfile.write(',')
		
		for j in range(len(Track_DiseaseStates_pop[i])): # Subpop + 1
			for istate in range(len(Track_DiseaseStates_pop[i][j])): # Loop through states
				outputfile.write(str(Track_DiseaseStates_pop[i][j][istate]))
				if istate != len(Track_DiseaseStates_pop[i][j]) - 1:  # Add ';' if not the last element
					outputfile.write(';')
			outputfile.write('|')
		outputfile.write(',')
		
		for j in range(len(Track_DiseaseStates_AddedInds[i])): # Subpop + 1
			for istate in range(len(Track_DiseaseStates_AddedInds[i][j])): # Loop through states
				outputfile.write(str(Track_DiseaseStates_AddedInds[i][j][istate]))
				if istate != len(Track_DiseaseStates_AddedInds[i][j]) - 1:  # Add ';' if not the last element
					outputfile.write(';')
			outputfile.write('|')
		outputfile.write(',')
		
		for j in range(len(Track_DiseaseStates_SecondUpdate[i])): # Subpop + 1
			for istate in range(len(Track_DiseaseStates_SecondUpdate[i][j])): # Loop through states
				outputfile.write(str(Track_DiseaseStates_SecondUpdate[i][j][istate]))
				if istate != len(Track_DiseaseStates_SecondUpdate[i][j]) - 1:  # Add ';' if not the last element
					outputfile.write(';')
			outputfile.write('|')
		outputfile.write(',')
		
		for j in range(len(Track_DiseaseStates_AfterDeaths_SecondUpdate[i])): # Subpop + 1
			for istate in range(len(Track_DiseaseStates_AfterDeaths_SecondUpdate[i][j])): # Loop through states
				outputfile.write(str(Track_DiseaseStates_AfterDeaths_SecondUpdate[i][j][istate]))
				if istate != len(Track_DiseaseStates_AfterDeaths_SecondUpdate[i][j]) - 1:  # Add ';' if not the last element
					outputfile.write(';')
			outputfile.write('|')
		outputfile.write(',')
		
		for j in range(nosubpops+1):
			outputfile.write(str(N_Emigration[i][j])+'|')
		outputfile.write(',')
		
		for j in range(len(Track_DiseaseStates_AddAge0s[i])): # Subpop + 1
			for istate in range(len(Track_DiseaseStates_AddAge0s[i][j])): # Loop through states
				outputfile.write(str(Track_DiseaseStates_AddAge0s[i][j][istate]))
				if istate != len(Track_DiseaseStates_AddAge0s[i][j]) - 1:  # Add ';' if not the last element
					outputfile.write(';')
			outputfile.write('|')
		outputfile.write(',')
		
		for j in range(nosubpops+1):
			outputfile.write(str(N_EmiMortality[i][j])+'|')
		outputfile.write(',')		
		
		for j in range(len(Track_DiseaseStates_ThirdUpdate[i])): # Subpop + 1
			for istate in range(len(Track_DiseaseStates_ThirdUpdate[i][j])): # Loop through states
				outputfile.write(str(Track_DiseaseStates_ThirdUpdate[i][j][istate]))
				if istate != len(Track_DiseaseStates_ThirdUpdate[i][j]) - 1:  # Add ';' if not the last element
					outputfile.write(';')
			outputfile.write('|')
		outputfile.write(',')
		
		for j in range(len(Track_DiseaseStates_AfterDeaths_ThirdUpdate[i])): # Subpop + 1
			for istate in range(len(Track_DiseaseStates_AfterDeaths_ThirdUpdate[i][j])): # Loop through states
				outputfile.write(str(Track_DiseaseStates_AfterDeaths_ThirdUpdate[i][j][istate]))
				if istate != len(Track_DiseaseStates_AfterDeaths_ThirdUpdate[i][j]) - 1:  # Add ';' if not the last element
					outputfile.write(';')
			outputfile.write('|')
		outputfile.write(',')
		
		for j in range(nosubpops+1):
			outputfile.write(str(N_Immigration[i][j])+'|')
		outputfile.write(',')				
					
		for j in range(nosubpops+1):
			outputfile.write(str(N_ImmiMortality[i][j])+'|')
		outputfile.write('\n')		
		
	# Logging message
	#stringout = 'The file summary_popAllTime_DiseaseStates.csv has been created'
	#logMsg(logfHndl,stringout)	
	
	# Close file
	outputfile.close()
	
	#End::DoOut_AllTimeDiseasePatch()



