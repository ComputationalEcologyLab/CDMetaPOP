Casey Day, 5/22/20
Multi-species CDMetaPOP inputs

Create runvars file to house run-specific parameters
Added one new column to Runvars to track both the number of species and the Popvars file for each species, separated by a semicolon (I think?)
Added column to popvars for competition coefficient. If more than two species we will need to think about this more
Created two files for each input labeled with S1 and S2 for each species.