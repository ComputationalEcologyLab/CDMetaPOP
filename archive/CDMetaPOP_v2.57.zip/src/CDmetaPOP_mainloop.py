# -------------------------------------------------------------------------------------------------
# CDmetaPOP_mainloop.py
# Author: Erin L Landguth, Casey Day
# Created: October 2020
# Description: This is the function/module file for target execution of main loop in parallel runs
# --------------------------------------------------------------------------------------------------

# Python specific functions
import numpy as np 
import pdb, random, copy, os, sys,datetime,signal
from ast import literal_eval 
from CDmetaPOP_Modules import * 
from CDmetaPOP_PostProcess import *
from CDmetaPOP_PreProcess import *
from CDmetaPOP_Mate import *
from CDmetaPOP_Emigration import *
from CDmetaPOP_Immigration import *
from CDmetaPOP_Offspring import *
from CDmetaPOP_Mortality import *

# ----------------------------------------------------------
# Global symbols, if any :))
#-----------------------------------------------------------
# when set True, routes session log traffic to BOTH the
# screen and to the log file. When False, log traffic just
# sent to log file alone.
msgVerbose = False

# --------------------------------------------------------------------------
def logMsg(outf,msg):
	'''
	logMsg() --log file message handler.
	Inputs:
	outf - open file handle
	msg -- string containing formatted message
	--always outputs to log file by default.
	--using msgVerbose, can be set to "Tee" output to stdout as well
	'''
	outf.write(msg+ '\n')
	if msgVerbose:
		print(("%s"%(msg)))
		
	# End::logMsg()

# --------------------------------------------------------------------------------------------------------------------
def main_loop(spcNO,fileans,irun,datadir,sizeans,constMortans,mcruns,looptime,nthfile_out,gridformat,gridsample,outputans,cdclimgentimelist,outdir,startcomp,implementcomp,passlogfHndl,XQs, nspecies, extinctQ, global_extinctQ,current_system_pid):
	'''
	Main loop here
	'''
	#if multiprocessing.current_process().name == "S1":
	#	pdb.set_trace()
	# Open the logfHndl file
	#passlogfHndl = outdir+"CDmetaPOP"+str(spcNO)+".log"
	logfHndl = open(passlogfHndl,'a')
	
	# Call function and store inputvariables
	batchVars,batchVarsIndex,nSimulations = loadFile(fileans,1,',',True)

	# ----------------------------------------	
	# Begin Batch Looping 
	# ----------------------------------------
	# This loop is defined by the number of rows in PopVars.csv
	for ibatch in range(nSimulations):
	
		# Store all information and the type of each, also do some error checks 
		xyfilename = datadir+batchVars['xyfilename'][ibatch]
		matecdmatfile = batchVars['mate_cdmat'][ibatch]
		dispOutcdmatfile = batchVars['migrateout_cdmat'][ibatch]
		dispBackcdmatfile = batchVars['migrateback_cdmat'][ibatch]
		straycdmatfile = batchVars['stray_cdmat'][ibatch]
		dispLocalcdmatfile = batchVars['disperseLocal_cdmat'][ibatch]
		matemoveno = batchVars['matemoveno'][ibatch]
		matemoveparA = batchVars['matemoveparA'][ibatch]
		matemoveparB = batchVars['matemoveparB'][ibatch]
		matemoveparC = batchVars['matemoveparC'][ibatch]
		matemovethreshval = batchVars['matemovethresh'][ibatch]
		freplace = batchVars['Freplace'][ibatch]
		mreplace = batchVars['Mreplace'][ibatch]
		selfing = batchVars['selfans'][ibatch]
		sexans = batchVars['sexans'][ibatch]
		assortmateModel_pass = batchVars['AssortativeMate_Model'][ibatch]
		assortmateC_pass = batchVars['AssortativeMate_Factor'][ibatch]
		dispmoveOutno = batchVars['migratemoveOutno'][ibatch]
		dispmoveOutparA = batchVars['migratemoveOutparA'][ibatch]
		dispmoveOutparB = batchVars['migratemoveOutparB'][ibatch]
		dispmoveOutparC = batchVars['migratemoveOutparC'][ibatch]
		dispmoveOutthreshval = batchVars['migratemoveOutthresh'][ibatch]
		dispmoveBackno = batchVars['migratemoveBackno'][ibatch]
		dispmoveBackparA = batchVars['migratemoveBackparA'][ibatch]
		dispmoveBackparB = batchVars['migratemoveBackparB'][ibatch]
		dispmoveBackparC = batchVars['migratemoveBackparC'][ibatch]
		dispmoveBackthreshval = batchVars['migratemoveBackthresh'][ibatch]
		StrBackno = batchVars['StrayBackno'][ibatch]
		StrBackparA = batchVars['StrayBackparA'][ibatch]
		StrBackparB = batchVars['StrayBackparB'][ibatch]
		StrBackparC = batchVars['StrayBackparC'][ibatch]
		StrBackthreshval = batchVars['StrayBackthresh'][ibatch]
		dispLocalno = batchVars['disperseLocalno'][ibatch]
		dispLocalparA = batchVars['disperseLocalparA'][ibatch]
		dispLocalparB = batchVars['disperseLocalparB'][ibatch]
		dispLocalparC = batchVars['disperseLocalparC'][ibatch]
		dispLocalthreshval = batchVars['disperseLocalthresh'][ibatch]
		homeattempt = batchVars['HomeAttempt'][ibatch]
		offno = batchVars['offno'][ibatch]
		inheritans_classfiles = batchVars['offans_InheritClassVars'][ibatch]
		equalClutch = batchVars['equalClutchSize'][ibatch]
		eggFreq = float(batchVars['eggFrequency'][ibatch])
		muterate = float(batchVars['muterate'][ibatch])
		mutationans = batchVars['mutationtype'][ibatch]
		loci = int(batchVars['loci'][ibatch])
		alleles = batchVars['alleles'][ibatch]
		mtdna = batchVars['mtdna'][ibatch]
		geneswap = int(batchVars['startGenes'][ibatch])
		cdevolveans = batchVars['cdevolveans'][ibatch]
		burningen_cdevolve = int(batchVars['startSelection'][ibatch])
		timecdevolve = batchVars['implementSelection'][ibatch]
		betaFile_selection = batchVars['betaFile_selection'][ibatch]		
		plasticans = batchVars['plasticgeneans'][ibatch]
		burningen_plastic = int(batchVars['startPlasticgene'][ibatch])
		timeplastic = batchVars['implementPlasticgene'][ibatch]		
		cdinfect = batchVars['cdinfect'][ibatch]
		transmissionprob = float(batchVars['transmissionprob'][ibatch])
		growans = batchVars['growth_option'][ibatch]
		sizeLoo = batchVars['growth_Loo'][ibatch] # Check sex ratios
		sizeR0 = batchVars['growth_R0'][ibatch]# Check sex ratios
		size_eqn_1 = batchVars['growth_temp_max'][ibatch]# Check sex ratios
		size_eqn_2 = batchVars['growth_temp_CV'][ibatch]# Check sex ratios
		size_eqn_3 = batchVars['growth_temp_t0'][ibatch]# Check sex ratios
		mat_set = batchVars['mature_length_set'][ibatch]
		mat_slope = batchVars['mature_eqn_slope'][ibatch]
		mat_int = batchVars['mature_eqn_int'][ibatch]
		egg_mean_ans = batchVars['Egg_Mean_ans'][ibatch]
		egg_mean_1 = float(batchVars['Egg_Mean_par1'][ibatch])
		egg_mean_2 = float(batchVars['Egg_Mean_par2'][ibatch])
		egg_percmort_mu = float(batchVars['Egg_Mortality'][ibatch])
		egg_percmort_sd = float(batchVars['Egg_Mortality_StDev'][ibatch])
		Femalepercent_egg = batchVars['Egg_FemalePercent'][ibatch]
		packans = batchVars['popmodel'][ibatch]
		packpar1 = float(batchVars['popmodel_par1'][ibatch])
		cor_mat_ans = batchVars['correlation_matrix'][ibatch]
		defaultAgeMature = batchVars['mature_defaultAge'][ibatch]
		subpopmort_pass = batchVars['subpopmort_file'][ibatch]
		egg_delay = int(batchVars['egg_delay'][ibatch])
			
		# -------------------------------
		# Distill some vars
		# -------------------------------
		# Grab the nthfile list range specific to user input, list or sequence
		#pdb.set_trace()
		if not isinstance(nthfile_out, (list,tuple)):
			nthfile_out = int(nthfile_out)
			if nthfile_out != 0:
				nthfile = list(range(0,looptime+nthfile_out,nthfile_out))
				del(nthfile[-1]) # Delete the last value 0, looptime - 1
			else:
				nthfile = [0]
		# If specified years with |
		else:
			nthfile = []
			# Split up list, removing space values, and appending to nthfile
			for inum in range(len(nthfile_out)):
				# Error check here if | at the end
				if len(nthfile_out[inum]) != 0:
					nthfile.append(int(nthfile_out[inum]))
		
		# Error check on nthfile, must be 1 less than looptime for indexing
		if max(nthfile) >= looptime:
			print('nthfile selection maximum value must be less than to looptime.')
			sys.exit(-1)
				
		# Store cdmat file information - header file (loadFile()) passes tuple or string if only 1
		if not isinstance(cdclimgentimelist, (list,tuple)):
			cdclimgentime = [cdclimgentimelist]
		else: 
			cdclimgentime = cdclimgentimelist
			
		# Create allele array
		if len(alleles.split(':')) == 1:
			alleles = int(batchVars['alleles'][ibatch])*np.ones(loci,int)
		else:
			alleles = np.asarray(alleles.split(':'),dtype = int)
		
		# ----------------------------
		# For Sex ratios option splits
		# ----------------------------
		# Deterministic mature set value either age or size
		if len(mat_set.split('~')) == 1:
			Fmat_set = mat_set.split('~')[0]
			Mmat_set = mat_set.split('~')[0]
			YYmat_set = mat_set.split('~')[0]
		elif len(mat_set.split('~')) == 2:
			Fmat_set = mat_set.split('~')[0]
			Mmat_set = mat_set.split('~')[1]
			YYmat_set = mat_set.split('~')[1]
		elif len(mat_set.split('~')) == 3:
			Fmat_set = mat_set.split('~')[0]
			Mmat_set = mat_set.split('~')[1]
			YYmat_set = mat_set.split('~')[2]
		else:
			print('mature_length_set must be 1 value for all sex classes or separated by :')
			sys.exit(-1)
		
		# Logistic equation for maturation as a function of size
		if len(mat_slope.split('~')) == 1:
			Fmat_slope = float(mat_slope.split('~')[0])
			Mmat_slope = float(mat_slope.split('~')[0])
			YYmat_slope = float(mat_slope.split('~')[0])
		elif len(mat_slope.split('~')) == 2:
			Fmat_slope = float(mat_slope.split('~')[0])
			Mmat_slope = float(mat_slope.split('~')[1])
			YYmat_slope = float(mat_slope.split('~')[1])
		elif len(mat_slope.split('~')) == 3:
			Fmat_slope = float(mat_slope.split('~')[0])
			Mmat_slope = float(mat_slope.split('~')[1])
			YYmat_slope = float(mat_slope.split('~')[2])
		else:
			print('logistic maturation equation parameter values must be 1 value for all sex classes or separated by :')
			sys.exit(-1)
		if len(mat_int.split('~')) == 1:
			Fmat_int = float(mat_int.split('~')[0])
			Mmat_int = float(mat_int.split('~')[0])
			YYmat_int = float(mat_int.split('~')[0])
		elif len(mat_int.split('~')) == 2:
			Fmat_int = float(mat_int.split('~')[0])
			Mmat_int = float(mat_int.split('~')[1])
			YYmat_int = float(mat_int.split('~')[1])
		elif len(mat_int.split('~')) == 3:
			Fmat_int = float(mat_int.split('~')[0])
			Mmat_int = float(mat_int.split('~')[1])
			YYmat_int = float(mat_int.split('~')[2])
		else:
			print('logistic maturation equation parameter values must be 1 value for all sex classes or separated by :')
			sys.exit(-1)
			
		# ---------------------------------
		# Some Error checking
		# ---------------------------------
		
		# DoEmigration() skipped and warning for if selection on
		if cdevolveans != 'N':
			if timecdevolve.find('Out') != -1:
				if dispOutcdmatfile == 'N':
					stringout = 'Warning: DoEmigration module skipped and spatial selection during this time frame specified, which will also be skipped.'
					logMsg(logfHndl,stringout)
						# 	
		# Constant mortality checks
		if not (constMortans == '1' or constMortans == '2'):
			print('Constant mortalities are compounded using option 1 or 2 specifiy correct values. If no constant mortalities are entered, then enter 1.')
			sys.exit(-1)
		
		# Check on cdevolve answer input
		if not (cdevolveans == '1' or cdevolveans == '2' or cdevolveans == '1_mat' or cdevolveans == '2_mat' or cdevolveans == 'N' or cdevolveans == 'M' or cdevolveans == 'G' or cdevolveans == 'MG_ind' or cdevolveans == 'MG_link' or cdevolveans == 'stray' or cdevolveans == '1_G_ind' or cdevolveans == '1_G_link' or cdevolveans.split('_')[0] == 'F' or cdevolveans.split('_')[0] == 'Hindex' or cdevolveans.split('_')[0] == 'P' or cdevolveans.split('_')[0] == 'FHindex'):
			print('CDEVOLVE answer either N, 1, 2, M, G, MG_ind, MG_link, 1_mat, 2_mat, stray, 1_G_ind, 1_G_link, Hindex, F, Plastic, or Multilocus.')
			sys.exit(-1)
			
		# For mature and size ans
		if (cdevolveans == 'M' or cdevolveans == 'MG_ind' or cdevolveans == 'MG_link' or cdevolveans == 'G' or cdevolveans == '1_G_ind' or cdevolveans == '1_G_link') and sizeans == 'N':
			print('CDEVOLVE answer is M or G and size answer must be Y.')
			sys.exit(-1)
		
		# For Hindex answer
		if cdevolveans.split('_')[0] == 'Hindex':
			# Split for Gaussian
			if cdevolveans.split('_')[1] == 'Gauss':
				if len(cdevolveans.split('_')[2].split(':')) != 6:
					print('CDEVOLVE answer is Hindex and 6 parameters for the Gaussian function must be specified, see user manual and example files.')
					sys.exit(-1)
			elif cdevolveans.split('_')[1] == 'Para':
				if len(cdevolveans.split('_')[2].split(':')) != 3:
					print('CDEVOLVE answer is Hindex and 3 parameters for the Parabolic function must be specified, see user manual and example files.')
					sys.exit(-1)
			elif cdevolveans.split('_')[1] == 'Step':
				if len(cdevolveans.split('_')[2].split(':')) != 3:
					print('CDEVOLVE answer is Hindex and 3 parameters for the Step function must be specified, see user manual and example files.')
					sys.exit(-1)
			elif cdevolveans.split('_')[1] == 'Linear':
				if len(cdevolveans.split('_')[2].split(':')) != 2:
					print('CDEVOLVE answer is Hindex and 2 parameters for the Linear function must be specified, see user manual and example files.')
					sys.exit(-1)					
			else:
				print('CDEVOLVE and Hindex parameter not entered correctly, check user manual and example files.')
				sys.exit(-1)
		
		# If cdevolve is turned on must have 2 alleles
		if cdevolveans != 'N' and alleles[0] != 2:
			print('Warning: More than 2 alleles per locus specified. CDEVOLVE only considers first 2 alleles in selection models (except Hindex scenario).')
		if plasticans != 'N' and alleles[0] != 2:
			print('Warning: More than 2 alleles per locus specified. Plastic gene turned on and only considers first 2 alleles in this model.')
		
		# For Plastic answer
		if plasticans != 'N':
			# Split for temp
			if ((plasticans.split('_')[0] != 'Temp') and (plasticans.split('_')[0] != 'Hab')):
				print('Plastic type (Temp/Hab) not entered corectly, check user manual and example files.')
				sys.exit(-1)
				
		if plasticans != 'N':
			# Split for temp
			if ((plasticans.split('_')[1] != 'dom') and (plasticans.split('_')[1] != 'rec') and (plasticans.split('_')[1] != 'codom')):
				print('Plastic type (dom/codom/rec) not entered corectly, check user manual and example files.')
				sys.exit(-1)
				
		if plasticans != 'N':	
			if ((timeplastic.find('Out') == -1) and (timeplastic.find('Back') == -1)):
				print('Plastic timing must be specified (e.g., Out or Back).')
				sys.exit(-1)
				
		# Must have more than 1 loci
		if loci <= 1:
			print('Currently, CDmetaPOP needs more than 1 locus to run.')
			sys.exit(-1)
		if cdevolveans == '1' or cdevolveans == '2' or cdevolveans == '1_mat' or cdevolveans == '2_mat' or cdevolveans == '1_G_ind' or cdevolveans == '1_G_link' or cdevolveans.split('_')[0] == 'Hindex' or cdevolveans.split('_')[0] == 'FHindex':
			if ((timecdevolve.find('Eggs') == -1) and (timecdevolve.find('Out') == -1) and (timecdevolve.find('Back') == -1) and timecdevolve.find('packing') == -1):
				print('CDEVOLVE timing must be specified (e.g., Out, Back or Eggs).')
				sys.exit(-1)
			
		# Error check on forward mutation in A and backward mutation in B
		#	Can only happen if cdevolve == 2.
		if mutationans == 'forwardAbackwardBrandomN' and (cdevolveans != '2' or cdevolveans == '2_mat'):
			print('This special case of mutation is for AAbb ancestors and 2-locus selection.')
			sys.exit(-1)		
					
		# grid format
		if (gridformat == 'cdpop' or gridformat == 'general' or gridformat == 'genalex' or gridformat == 'genepop' or gridformat == 'structure') == False:
			print('Grid format parameter not an option.')
			sys.exit(-1)
		
		# If genepop, some conditions
		if gridformat == 'genepop' and (alleles[0] > 99 or loci > 99):
			print('GENEPOP format requires less than 99 alleles and 99 loci.')
			sys.exit(-1)
		
		# Check burn in times
		if cdevolveans != 'N' and burningen_cdevolve < geneswap:
			stringout = 'Warning: Selection burnin time < time at which genetic exchange is to initialize, setting burnin time = start genetic exchange time.'
			logMsg(logfHndl,stringout)
			
			burningen_cdevolve = geneswap
		if plasticans != 'N' and burningen_plastic < geneswap:
			stringout = 'Warning: Selection burnin time < time at which genetic exchange is to initialize, setting burnin time = start genetic exchange time.'
			logMsg(logfHndl,stringout)
			burningen_plastic = geneswap
			
		# Egg frequency
		if eggFreq > 1:
			print('Egg frequency must be less than or equal to 1.')
			sys.exit(-1)
			
		# Inherit answer can only be:
		if not (inheritans_classfiles == 'random' or inheritans_classfiles == 'Hindex' or inheritans_classfiles == 'mother'):
			print('Inherit answer for multiple class files is not correct: enter either random or Hindex.')
			sys.exit(-1)
			
		# If inherit answer uses Hindex, mutation can't be on
		if muterate != 0.0 and (inheritans_classfiles == 'Hindex' or inheritans_classfiles == 'mother'):
			print('Currently, mutation is not operating with Hindex inheritance options.')
			sys.exit(-1)
			
		# If egg_delay is gretter than 1
		if egg_delay > 1:
			print('Currently, egg delay is not operating beyond 1 year/time unit.')
			sys.exit(-1)
		
		# Reproduction answers checks
		if (sexans == 'N' or sexans == 'Y' or sexans == 'H') == False:
			print('Reproduction choices either N, Y or H, check user manual.')
			sys.exit(-1)
		if sexans == 'H':
			if isinstance(selfing,float): # selfing answer must be entered in as a probability value, not string
				print('Hermaphroditic mating structure specified - H - then must specify the selfing probability.')
				sys.exit(-1)
				
		# ---------------------------------------------	
		# Begin Monte-Carlo Looping
		# ---------------------------------------------
		
		# range(mcruns) is typically 10 - 50...and it takes a long time.
		for ithmcrun in range(mcruns):	
			
			# Timing events: start
			start_timeMC = datetime.datetime.now()
			# Keep track so extinction message are printed only once
			temp_extinct = 0
		
			# -----------------------------------------
			# Create storage variables
			# ------------------------------------------	
			# These variables will be stored in output.csv at the end of the simulation						
			
			# GetMetrics()
			Track_p1 = []
			Track_p2 = []
			Track_q1 = []
			Track_q2 = []
			Track_Alleles = []
			Track_He = []
			Track_Ho = []
			Track_N_Init_pop = []
			Track_N_Init_age = []
			Track_N_Init_class = []
			Track_K = []
			Track_CaptureCount_Out = []
			Track_CaptureCount_ClassOut = []
			Track_CaptureCount_Back = []
			Track_CaptureCount_ClassBack = []
			maxfit = []
			minfit = []
									
			# DoMate()
			Track_FAvgMate = []
			Track_MAvgMate = []
			Track_FSDMate = []
			Track_MSDMate = []
			Track_MateDistCD = []
			Track_MateDistCDstd = []
			Track_BreedEvents = []
			Track_AAaaMates = []
			Track_AAAAMates =[]
			Track_aaaaMates = []
			Track_AAAaMates = []
			Track_aaAaMates = []
			Track_AaAaMates = []
			Track_YYsAdded = []
			Track_BreedFemales = []
			Track_BreedMales = []
			Track_BreedYYMales = []
			Track_MatureCount = []
			Track_ImmatureCount = []
			Track_ToTFemales = []
			Track_ToTMales = []
			Track_ToTYYMales = []
			
			# DoOffspring
			Track_Births = []
			Track_EggDeaths = []
			Track_BirthsYY = []
			
			# DoUpdate
			Track_N_back_age = []
			Track_N_out_age = []
			
			# Emigration()
			N_Emigration_pop = []
			N_Emigration_age = []
			subpopemigration = []			
			F_EmiDist = []
			M_EmiDist = []						
			F_EmiDist_sd = []
			M_EmiDist_sd = []
			SelectionDeathsEmi = []	
			DisperseDeathsEmi = []
			PackingDeathsEmi = []
			PackingDeathsEmiAge = []
			MgSuccess = []
			AdultNoMg = []
			Track_YYSelectionPackDeathsEmi = []
			Track_WildSelectionPackDeathsEmi = []
			SelectionDeaths_Age0s = []
			N_beforePack_pop = []
			N_beforePack_age = []
			Track_KadjEmi = []
			
			# Mortlity after Emigration
			N_EmiMortality = []
			PopDeathsOUT = []
			AgeDeathsOUT = []
			SizeDeathsOUT = []
			
			# Immigration
			N_Immigration_pop = []
			N_Immigration_age = []
			subpopimmigration = []
			F_HomeDist = []
			M_HomeDist = []					
			F_HomeDist_sd = []
			M_HomeDist_sd = []
			F_StrayDist = []
			M_StrayDist = []					
			F_StrayDist_sd = []
			M_StrayDist_sd = []
			F_ZtrayDist = []
			M_ZtrayDist = []					
			F_ZtrayDist_sd = []
			M_ZtrayDist_sd = []
			SelectionDeathsImm = []
			DisperseDeathsImm = []
			PackingDeathsImmAge = []
			PackingDeathsImm = []
			StrSuccess = []
			Track_YYSelectionPackDeathsImmi = []
			Track_WildSelectionPackDeathsImmi = []
			Track_KadjImmi = []

			# Mortality after immigration
			N_ImmiMortality = []
			PopDeathsIN = []
			AgeDeathsIN = []
			SizeDeathsIN = []
			
			# DoOutput()
			Infected = []
			Residors = []
			Strayers1 = []
			Strayers2 = []
			Immigrators = []
			IDispersers = []
			RDispersers = []
			PopSizes_Mean = []
			PopSizes_Std = []
			AgeSizes_Mean = []
			AgeSizes_Std = []
			ClassSizes_Mean = []
			ClassSizes_Std = []
			
			# Non-tracking variables - create empty 2-D list
			noOffspring_temp = [np.asarray([]),np.asarray([])] 
			Bearpairs_temp = [[[-9999,-9999]],[[-9999,-9999]]]
					
			# ------------------------------------	
			# Call DoPreProcess()
			# ------------------------------------
			
			# Timing events: start
			start_time1 = datetime.datetime.now()
			
			# Call function
			tupPreProcess = DoPreProcess(outdir,datadir,irun,ithmcrun,\
			xyfilename,loci,alleles,0,logfHndl,cdevolveans,cdinfect,\
			subpopemigration,subpopimmigration,sizeans,eggFreq,Fmat_set,Mmat_set,Fmat_int,Fmat_slope,Mmat_int,Mmat_slope,burningen_cdevolve,cor_mat_ans,inheritans_classfiles,sexans,YYmat_set,YYmat_slope,YYmat_int,defaultAgeMature,spcNO,ibatch,betaFile_selection)
			
			ithmcrundir = tupPreProcess[0]			
			fitvals_pass = tupPreProcess[1] # sex ratio check throughout
			allelst = tupPreProcess[2]
			subpopemigration = tupPreProcess[3]
			subpopimmigration = tupPreProcess[4]
			age_percmort_out_mu = tupPreProcess[5]
			age_percmort_back_mu = tupPreProcess[6]
			age_Mg = tupPreProcess[7]# sex ratio check throughout
			age_S = tupPreProcess[8]# sex ratio check throughout			
			age_mu_pass = tupPreProcess[9]
			age_size_mean = tupPreProcess[10]
			age_size_std = tupPreProcess[11]			
			xgridpop = tupPreProcess[12]
			ygridpop = tupPreProcess[13]			
			SubpopIN_init = tupPreProcess[14]
			N0 = tupPreProcess[15]
			K_mu = tupPreProcess[16]
			dtype = tupPreProcess[17]
			outsizevals_pass = tupPreProcess[18]
			backsizevals_pass = tupPreProcess[19]
			popmort_out_pass = tupPreProcess[20]
			popmort_back_pass = tupPreProcess[21]
			Mg_pass = tupPreProcess[22]
			Str_pass = tupPreProcess[23]
			eggmort_pass = tupPreProcess[24]
			setmigrate = tupPreProcess[25]
			#M_mature = tupPreProcess[26]
			#F_mature = tupPreProcess[27]
			age_mature = tupPreProcess[26]# sex ratio check throughout
			age_sigma_pass = tupPreProcess[27]
			outgrowdays_pass = tupPreProcess[28]
			backgrowdays_pass = tupPreProcess[29]
			Kmu_pass = tupPreProcess[30]
			age_capture_out = tupPreProcess[31] # sex ratio check throughout
			age_capture_back = tupPreProcess[32] # sex ratio check throughout
			Kstd_pass = tupPreProcess[33]
			K_std = tupPreProcess[34]
			popmort_out_sd_pass = tupPreProcess[35]
			popmort_back_sd_pass = tupPreProcess[36]
			eggmort_sd_pass = tupPreProcess[37]
			outsizevals_sd_pass = tupPreProcess[38]
			backsizevals_sd_pass = tupPreProcess[39]
			outgrowdays_sd_pass = tupPreProcess[40]
			backgrowdays_sd_pass = tupPreProcess[41]
			size_percmort_out_mu = tupPreProcess[42] 
			size_percmort_back_mu = tupPreProcess[43] 
			age_percmort_out_sd = tupPreProcess[44] 
			age_percmort_back_sd = tupPreProcess[45] 
			size_percmort_out_sd = tupPreProcess[46] 
			size_percmort_back_sd = tupPreProcess[47] 
			pop_capture_back_pass = tupPreProcess[48]
			pop_capture_out_pass = tupPreProcess[49]
			pop_capture_back = tupPreProcess[50]
			natal = tupPreProcess[51]
			cor_mat = tupPreProcess[52]
			migrate = tupPreProcess[53]
			N0_pass = tupPreProcess[54]
			allefreqfiles_pass = tupPreProcess[55]
			classvarsfiles_pass = tupPreProcess[56]
			PopTag = tupPreProcess[57] # To pass into AddIndividuals, Emigration, Immigration
			comp_coef_pass = tupPreProcess[58]
			xvars_betas_pass = tupPreProcess[59]
			tempbetas_selection = tupPreProcess[60]
			outhabvals_pass = tupPreProcess[61]
			backhabvals_pass = tupPreProcess[62]
			f_leslie_pass = tupPreProcess[63]
			f_leslie_std_pass = tupPreProcess[64]
			ageDispProb = tupPreProcess[65] # age/size based probability local dispersal
			
			# Grab first one only
			K = K_mu # Initialize K with mu		
						
			# Print to log
			stringout = 'DoPreProcess(): '+str(datetime.datetime.now() -start_time1) + ''
			logMsg(logfHndl,stringout)
			if multiprocessing.current_process().name == "S0" or multiprocessing.current_process().name == "MainProcess":
				print(('DoPreProcess(): ',str(datetime.datetime.now() -start_time1),''))
			
			# ---------------------------------
			# Call GetMetrics()
			# ---------------------------------
			
			# Timing events: start
			start_time1 = datetime.datetime.now()
			
			GetMetrics(SubpopIN_init,K,Track_N_Init_pop,Track_K,loci,alleles,0,Track_Ho,Track_Alleles,Track_He,Track_p1,Track_p2,Track_q1,Track_q2,Infected,Residors,Strayers1,Strayers2,Immigrators,PopSizes_Mean,PopSizes_Std,AgeSizes_Mean,AgeSizes_Std,Track_N_Init_age,sizeans,age_size_mean,ClassSizes_Mean,ClassSizes_Std,Track_N_Init_class,packans,RDispersers,IDispersers,xvars_betas_pass,tempbetas_selection,maxfit,minfit,cdevolveans)
			# Print to log
			stringout = 'GetMetrics() Initial: '+str(datetime.datetime.now() -start_time1) + ''
			logMsg(logfHndl,stringout)
				
			# ---------------------------------
			# Error statements
			# ---------------------------------			
			# Error statement here in case no females or males, then break
			#if Track_ToTFemales[0][0]==0 or (Track_ToTMales[0][0] + Track_ToTYYMales[0][0])==0:
			if Track_N_Init_pop[0][0] == 0:
				print('There are no individuals to begin time loop.\n')
				
				#ThisSystem = psutil.Process(os.getpid())
				#ThisSystem.terminate()
				#os.killpg(current_system_pid, signal.SIGTERM)
				
				sys.exit(-1)
				
			# ----------------------------------------------------
			# Call DoUpdate() - output initial file here ind-1.csv
			# ----------------------------------------------------
							
			# Timing events: start
			start_time1 = datetime.datetime.now()
			
			DoUpdate(packans,SubpopIN_init,K,xgridpop,ygridpop,-1,nthfile,ithmcrundir,loci,alleles,logfHndl,'Initial','N','N',defaultAgeMature,[],burningen_cdevolve,[],[],[],[],[],[])
			# Print to log
			stringout = 'DoUpdate(): '+str(datetime.datetime.now() -start_time1) + ''
			logMsg(logfHndl,stringout)
			
			# -------------------------------------------
			# Start Generation Looping 
			# -------------------------------------------
			# Begin generation loop
			for gen in range(looptime):
				
				# Timing events: start
				start_timeGen = datetime.datetime.now()
									
				# If initial generation - update with initial populations
				if gen == 0:
					SubpopIN = SubpopIN_init
					del SubpopIN_init
					# Use NatalPop 
					sourcePop = 'NatalPop'		
				else: # This was for versions previous v1.37
					#sourcePop = 'ImmiPop'
					sourcePop = 'NatalPop'
				
				# Exit the system if population is 0 or 1
				checkPopN = [len(SubpopIN[x]) for x in range(0,len(SubpopIN))] 
				if sum(checkPopN) == 0:
					stringout = 'Species is extinct.'
					logMsg(logfHndl,stringout)
					# If not extinct from previous generation
					if temp_extinct == 0:					
						print(('Species ' + str(spcNO) + ' went extinct.'))
						temp_extinct = 1
					# Track extinctions
					extinctQ.put(0)
				else:
					# Track extinctions
					extinctQ.put(1)
				# List to track extinctions
				if multiprocessing.current_process().name == "S0" or multiprocessing.current_process().name == "MainProcess":
					ext_list = []	
					for ispecies in range(nspecies):
						ext_list.append(extinctQ.get(block=True))
					# If all species extinct, exit
					if sum(ext_list) == 0:
						# Exit the system if population is 0 or 1
						stringout = 'All species extinct after generation '+str(gen-1)+', program ended.\n'
						logMsg(logfHndl,stringout)
						if multiprocessing.current_process().name == "S0" or multiprocessing.current_process().name == "MainProcess":
							print('All species extinct')
						#print('Population went extinct after generation '+str(gen-1)+'.\n')
						for ispecies in range(nspecies):
							global_extinctQ.put(1)
					else:
						for ispecies in range(nspecies):
							global_extinctQ.put(0)	
				if global_extinctQ.get() == 1:
					break
				
				# ---------------------------------
				# Call CDClimate()
				# ---------------------------------			
				# Timing events: start
				start_time1 = datetime.datetime.now()
				
				# Check gen time equal to cdclimgentime
				for icdtime in range(len(cdclimgentime)): 
					if gen == int(cdclimgentime[icdtime]):
						tupClimate = DoCDClimate(datadir,icdtime,cdclimgentime,matecdmatfile,dispOutcdmatfile,\
						dispBackcdmatfile,straycdmatfile,matemoveno,dispmoveOutno,dispmoveBackno,StrBackno,matemovethreshval,dispmoveOutthreshval,dispmoveBackthreshval,StrBackthreshval,matemoveparA,matemoveparB,matemoveparC,dispmoveOutparA,dispmoveOutparB,dispmoveOutparC,dispmoveBackparA,dispmoveBackparB,dispmoveBackparC,StrBackparA,StrBackparB,StrBackparC,Mg_pass,Str_pass,Kmu_pass,outsizevals_pass,backsizevals_pass,outgrowdays_pass,backgrowdays_pass,fitvals_pass,popmort_back_pass,popmort_out_pass,eggmort_pass,Kstd_pass,popmort_back_sd_pass,popmort_out_sd_pass,eggmort_sd_pass,outsizevals_sd_pass,backsizevals_sd_pass,outgrowdays_sd_pass,backgrowdays_sd_pass,pop_capture_back_pass,pop_capture_out_pass,cdevolveans,N0_pass,allefreqfiles_pass,classvarsfiles_pass,assortmateModel_pass,assortmateC_pass,subpopmort_pass,PopTag,dispLocalcdmatfile,dispLocalno,dispLocalparA,dispLocalparB,dispLocalparC,dispLocalthreshval,comp_coef_pass,betaFile_selection,xvars_betas_pass,outhabvals_pass,backhabvals_pass,age_mu_pass,age_sigma_pass,f_leslie_pass,f_leslie_std_pass)	

						cdmatrix_mate = tupClimate[0]
						cdmatrix_FOut = tupClimate[1]
						cdmatrix_MOut = tupClimate[2]
						cdmatrix_FBack = tupClimate[3]
						cdmatrix_MBack = tupClimate[4]
						cdmatrix_StrBack = tupClimate[5]				
						thresh_mate = tupClimate[6]
						thresh_FOut = tupClimate[7]
						thresh_MOut = tupClimate[8]				
						thresh_FBack = tupClimate[9]
						thresh_MBack = tupClimate[10]
						thresh_Str = tupClimate[11]
						Mg = tupClimate[12]
						Str = tupClimate[13]
						Str_ScaleMin = tupClimate[14]
						Str_ScaleMax = tupClimate[15]
						FdispBack_ScaleMin = tupClimate[16]
						FdispBack_ScaleMax = tupClimate[17]
						MdispBack_ScaleMin = tupClimate[18]
						MdispBack_ScaleMax = tupClimate[19]
						FdispOut_ScaleMin = tupClimate[20]
						FdispOut_ScaleMax = tupClimate[21]
						MdispOut_ScaleMin = tupClimate[22]
						MdispOut_ScaleMax = tupClimate[23]
						mate_ScaleMin = tupClimate[24]
						mate_ScaleMax = tupClimate[25]
						outsizevals_mu = tupClimate[26]
						backsizevals_mu = tupClimate[27]
						outgrowdays_mu = tupClimate[28]
						backgrowdays_mu = tupClimate[29]
						fitvals = tupClimate[30]
						K_mu = tupClimate[31]
						popmort_back_mu = tupClimate[32]
						popmort_out_mu = tupClimate[33]
						eggmort_mu = tupClimate[34]
						K_std = tupClimate[35]
						popmort_back_sd = tupClimate[36]
						popmort_out_sd = tupClimate[37]
						eggmort_sd = tupClimate[38]
						outsizevals_sd = tupClimate[39]
						backsizevals_sd = tupClimate[40]
						outgrowdays_sd = tupClimate[41]
						backgrowdays_sd = tupClimate[42]
						pop_capture_back = tupClimate[43]
						pop_capture_out = tupClimate[44]
						mateno = tupClimate[45]
						FdispOutno = tupClimate[46]
						MdispOutno = tupClimate[47]
						FdispBackno = tupClimate[48]
						MdispBackno = tupClimate[49]
						Strno = tupClimate[50]
						tempN0 = tupClimate[51]
						tempAllelefile = tupClimate[52]
						tempClassVarsfile = tupClimate[53]
						assortmateModel = tupClimate[54]
						assortmateC = tupClimate[55]
						subpopmort_mat = tupClimate[56]
						FdispmoveOutparA = tupClimate[57]
						MdispmoveOutparA = tupClimate[58]
						FdispmoveOutparB = tupClimate[59]
						MdispmoveOutparB = tupClimate[60]
						FdispmoveOutparC = tupClimate[61]
						MdispmoveOutparC = tupClimate[62]
						FdispmoveBackparA = tupClimate[63]
						MdispmoveBackparA = tupClimate[64]
						FdispmoveBackparB = tupClimate[65]
						MdispmoveBackparB = tupClimate[66]
						FdispmoveBackparC = tupClimate[67]
						MdispmoveBackparC = tupClimate[68]
						cdmatrix_dispLocal = tupClimate[69]
						dispLocalparA = tupClimate[70]
						dispLocalparB = tupClimate[71]
						dispLocalparC = tupClimate[72]
						thresh_dispLocal = tupClimate[73]
						dispLocal_ScaleMin = tupClimate[74]
						dispLocal_ScaleMax = tupClimate[75]	
						comp_coef = tupClimate[76]
						betas_selection = tupClimate[77]
						xvars_betas = tupClimate[78]
						outhabvals = tupClimate[79]
						backhabvals = tupClimate[80]
						age_mu = tupClimate[81]	# Not updated in cdclimate yet
						age_sigma = tupClimate[82]	# Not updated in cdclimate yet
						f_leslie_mu = tupClimate[83] # Not updated in cdclimate yet	
						f_leslie_std = tupClimate[84]	# Not updated in cdclimate yet					
						
						# ----------------------------------------
						# Introduce new individuals
						# ----------------------------------------
						if (gen != 0 and len(N0_pass[0].split('|')) > 1):
							SubpopIN = AddIndividuals(SubpopIN,tempN0,tempAllelefile,tempClassVarsfile,datadir,loci,alleles,sizeans,cdinfect,cdevolveans,burningen_cdevolve,fitvals,eggFreq,Fmat_set,Mmat_set,Fmat_int,Fmat_slope,Mmat_int,Mmat_slope,dtype,N0,natal,gen,PopTag,sexans,YYmat_set,YYmat_slope,YYmat_int,defaultAgeMature,logfHndl)			
				
				# -------------------------------------------
				# Update stochastic parameters each year here
				# -------------------------------------------
				
				tupStoch = DoStochasticUpdate(K_mu,K_std,popmort_back_mu,popmort_back_sd,popmort_out_mu,popmort_out_sd,eggmort_mu,eggmort_sd,outsizevals_mu,outsizevals_sd,backsizevals_mu,backsizevals_sd,outgrowdays_mu,outgrowdays_sd,backgrowdays_mu,backgrowdays_sd,age_percmort_out_mu,age_percmort_out_sd,age_percmort_back_mu,age_percmort_back_sd,size_percmort_out_mu,size_percmort_out_sd,size_percmort_back_mu,size_percmort_back_sd,egg_percmort_mu,egg_percmort_sd,cor_mat,age_mu,age_sigma,f_leslie_mu,f_leslie_std)
				K = tupStoch[0]
				popmort_back = tupStoch[1]
				popmort_out = tupStoch[2]
				eggmort_patch = tupStoch[3]
				outsizevals = tupStoch[4]
				backsizevals = tupStoch[5]
				outgrowdays = tupStoch[6]
				backgrowdays = tupStoch[7]
				age_percmort_out = tupStoch[8] # sex ratio check throughout
				age_percmort_back = tupStoch[9] # sex ratio check throughout
				size_percmort_out = tupStoch[10] # sex ratio check throughout
				size_percmort_back = tupStoch[11] # sex ratio check throughout
				eggmort_pop = tupStoch[12]
				f_ind = tupStoch[13]
				f_leslie = tupStoch[14]
				
				# Print to log
				stringout = 'DoCDClimate(): '+str(datetime.datetime.now() -start_time1) + ''
				logMsg(logfHndl,stringout)
				
				# ---------------------------------------
				# Call DoMate()
				# ---------------------------------------
				#pdb.set_trace()
				# Timing events: start
				start_time1 = datetime.datetime.now()				
				
				Bearpairs_temp = DoMate(SubpopIN,K,\
				freplace,mreplace,mateno,thresh_mate,\
				cdmatrix_mate,Track_MateDistCD,xgridpop,\
				ygridpop,Track_MateDistCDstd,Track_FAvgMate,Track_MAvgMate,Track_FSDMate,Track_MSDMate,Track_BreedEvents,gen,sourcePop,mate_ScaleMax,mate_ScaleMin,matemoveparA,matemoveparB,matemoveparC,Femalepercent_egg,eggFreq,sexans,selfing,assortmateC,Track_AAaaMates,Track_AAAAMates,Track_aaaaMates,Track_AAAaMates,Track_aaAaMates,Track_AaAaMates,assortmateModel,subpopmort_mat,Track_BreedFemales,Track_BreedMales,Track_BreedYYMales,Track_MatureCount, Track_ImmatureCount,Track_ToTFemales,Track_ToTMales,Track_ToTYYMales,egg_delay,Bearpairs_temp)
				
				# Print to log
				stringout = 'DoMate(): '+str(datetime.datetime.now() -start_time1) + ''
				logMsg(logfHndl,stringout)
				if Track_ToTFemales[gen][0]==0 or (Track_ToTMales[gen][0] + Track_ToTYYMales[gen][0])==0:
					if temp_extinct == 0:
						print(('There are no more females or males left from species ' + str(spcNO) + ' after year '+str(gen)+'.\n'))
					#break
								
				# ---------------------------------------
				# Call DoOffspring()
				# ---------------------------------------
				#pdb.set_trace()
				# Timing events: start
				start_time1 = datetime.datetime.now()			
				noOffspring_temp, Bearpairs_temp = DoOffspring(offno,Bearpairs_temp,\
				Track_Births,transmissionprob,gen,K,sourcePop,\
				f_ind,age_sigma,sizeans,\
				egg_mean_1,egg_mean_2,egg_mean_ans,equalClutch,dtype,eggmort_patch,Track_EggDeaths,eggmort_pop,Track_BirthsYY,egg_delay,noOffspring_temp)
							
				# Print to log
				stringout = 'DoOffspring(): '+str(datetime.datetime.now() -start_time1) + ''
				logMsg(logfHndl,stringout)
							
				# ----------------------------------------------------------------
				# Call 2nd DoUpdate() - grow, age/mature (selection option),egglay,capture, output ind.csv file;no Age0s; ind.csv
				# ----------------------------------------------------------------
				#pdb.set_trace()
				# Timing events: start
				start_time1 = datetime.datetime.now()
				SubpopIN = DoUpdate(packans,SubpopIN,K,xgridpop,ygridpop,gen,nthfile,ithmcrundir,loci,alleles,logfHndl,'Middle',growans,cdevolveans,defaultAgeMature,fitvals,burningen_cdevolve,age_capture_back,pop_capture_back,Track_CaptureCount_Back,Track_CaptureCount_ClassBack,sizeans,age_size_mean,Track_N_back_age,eggFreq,backsizevals,sizeLoo,sizeR0,size_eqn_1,size_eqn_2,size_eqn_3,backgrowdays,sourcePop,plasticans,burningen_plastic,timeplastic,geneswap,backhabvals)
												
				# Print to log
				stringout = 'Second DoUpdate(): '+str(datetime.datetime.now() -start_time1) + ''
				logMsg(logfHndl,stringout)
				
				# ------------------------------------------
				# Call DoEmigration()
				# ------------------------------------------
				#pdb.set_trace()				
				# Timing events: start
				start_time1 = datetime.datetime.now()
				SubpopIN = DoEmigration(SubpopIN,K,FdispOutno,\
				MdispOutno,cdmatrix_FOut,cdmatrix_MOut,gen,F_EmiDist,M_EmiDist,cdevolveans,fitvals,F_EmiDist_sd,M_EmiDist_sd,subpopemigration,\
				SelectionDeathsEmi,DisperseDeathsEmi,burningen_cdevolve,Mg,\
				MgSuccess,AdultNoMg,age_Mg,thresh_FOut,thresh_MOut,N_Emigration_pop,sourcePop,dtype,setmigrate,sizeans,age_size_mean,PackingDeathsEmi,N_Emigration_age,loci,muterate,mtdna,mutationans,FdispOut_ScaleMax,FdispOut_ScaleMin,MdispOut_ScaleMax,MdispOut_ScaleMin,FdispmoveOutparA,FdispmoveOutparB,FdispmoveOutparC,MdispmoveOutparA,MdispmoveOutparB,MdispmoveOutparC,packans,PackingDeathsEmiAge,packpar1,timecdevolve,age_percmort_out,migrate,outsizevals,PopTag,subpopmort_mat,Track_YYSelectionPackDeathsEmi,Track_WildSelectionPackDeathsEmi,plasticans,burningen_plastic,timeplastic,noOffspring_temp,Bearpairs_temp,age_size_std,Femalepercent_egg,transmissionprob,age_mature,Mmat_slope,Mmat_int,Fmat_slope,Fmat_int,Mmat_set,Fmat_set,YYmat_slope,YYmat_int,YYmat_set,alleles,geneswap,allelst,assortmateModel,inheritans_classfiles,eggFreq,sexans,N_beforePack_pop,N_beforePack_age,SelectionDeaths_Age0s,comp_coef,XQs,Track_KadjEmi,Track_KadjImmi,startcomp,spcNO,implementcomp,betas_selection,xvars_betas,maxfit,minfit)
				
				# Delete the noOffspring_temp and Bearpairs_temp egg_delay spots used: the first spot in list
				if len(noOffspring_temp) != 0: # But check for extinction
					del(noOffspring_temp[0])
					del(Bearpairs_temp[0])
					# Append a new empty spot for next years cohort
					noOffspring_temp.append(np.asarray([]))
					Bearpairs_temp.append([[-9999,-9999]])				
				
				# Print to log
				stringout = 'DoEmigration(): '+str(datetime.datetime.now() -start_time1) + ''
				logMsg(logfHndl,stringout)
						
				# ----------------------------------------
				# Call DoMortality() - when 'Out'
				# ----------------------------------------			
				#pdb.set_trace()
				start_time1 = datetime.datetime.now() # Timing events: start
				SubpopIN = DoMortality(SubpopIN,K,PopDeathsOUT,\
				popmort_out,age_percmort_out,\
				gen,N_EmiMortality,AgeDeathsOUT,sizeans,age_size_mean,size_percmort_out,SizeDeathsOUT,constMortans,packans,'OUT')
				
				# Print to log
				stringout = 'DoOutMortality(): '+str(datetime.datetime.now() -start_time1) + ''
				logMsg(logfHndl,stringout)
				
				# ----------------------------------------------------
				# Call DoUpdate() - grow, capture, and optional output indSample.csv
				# ----------------------------------------------------
				#pdb.set_trace()
				start_time1 = datetime.datetime.now() # Timing events: start
				SubpopIN = DoUpdate(packans,SubpopIN,K,xgridpop,ygridpop,gen,nthfile,ithmcrundir,loci,alleles,logfHndl,gridsample,growans,cdevolveans,defaultAgeMature,fitvals,burningen_cdevolve,age_capture_out,pop_capture_out,Track_CaptureCount_Out,Track_CaptureCount_ClassOut,sizeans,age_size_mean,Track_N_out_age,eggFreq,outsizevals,sizeLoo,sizeR0,size_eqn_1,size_eqn_2,size_eqn_3,outgrowdays,'EmiPop',plasticans,burningen_plastic,timeplastic,geneswap,outhabvals,age_mature,Mmat_slope,Mmat_int,Fmat_slope,Fmat_int,Mmat_set,Fmat_set,YYmat_int,YYmat_slope,YYmat_set)
					
				# Print to log
				stringout = 'Third DoUpdate(): '+str(datetime.datetime.now() -start_time1) + ''
				logMsg(logfHndl,stringout)
				
				# ------------------------------------------
				# Call DoImmigration()
				# ------------------------------------------			
				#pdb.set_trace()
				start_time1 = datetime.datetime.now() # Timing events: start
				SubpopIN = DoImmigration(SubpopIN,K,natal,FdispBackno,\
				MdispBackno,cdmatrix_FBack,cdmatrix_MBack,gen,cdevolveans,fitvals,subpopimmigration,\
				SelectionDeathsImm,DisperseDeathsImm,burningen_cdevolve,Str,\
				StrSuccess,\
				Strno,cdmatrix_StrBack,age_S,thresh_FBack,thresh_MBack,thresh_Str,N_Immigration_pop,dtype,sizeans,age_size_mean,PackingDeathsImm,N_Immigration_age,FdispBack_ScaleMax,FdispBack_ScaleMin,MdispBack_ScaleMax,MdispBack_ScaleMin,FdispmoveBackparA,FdispmoveBackparB,FdispmoveBackparC,MdispmoveBackparA,MdispmoveBackparB,MdispmoveBackparC,Str_ScaleMax,Str_ScaleMin,StrBackparA,StrBackparB,StrBackparC,packans,PackingDeathsImmAge,packpar1,homeattempt,timecdevolve,F_StrayDist,M_StrayDist,F_StrayDist_sd,M_StrayDist_sd,F_ZtrayDist,M_ZtrayDist,F_ZtrayDist_sd,M_ZtrayDist_sd,F_HomeDist,M_HomeDist,F_HomeDist_sd,M_HomeDist_sd,backsizevals,PopTag,subpopmort_mat,Track_YYSelectionPackDeathsImmi,Track_WildSelectionPackDeathsImmi,cdmatrix_dispLocal,dispLocalparA,dispLocalparB,dispLocalparC,thresh_dispLocal,dispLocal_ScaleMin,dispLocal_ScaleMax,dispLocalno,plasticans,burningen_plastic,timeplastic,age_percmort_back,comp_coef,XQs,Track_KadjImmi,Track_KadjEmi,startcomp,spcNO,implementcomp,betas_selection,xvars_betas,maxfit,minfit,f_leslie,f_leslie_std,ageDispProb)
				
				# Print to log
				stringout = 'DoImmigration(): '+str(datetime.datetime.now() -start_time1) + ''
				logMsg(logfHndl,stringout)
							
				#pdb.set_trace()
				# ------------------------------------------
				# Call DoMortality() - when 'Back'
				# ------------------------------------------
				# Timing events: start
				start_time1 = datetime.datetime.now()
				SubpopIN = DoMortality(SubpopIN,K,PopDeathsIN,\
				popmort_back,age_percmort_back,\
				gen,N_ImmiMortality,AgeDeathsIN,sizeans,age_size_mean,size_percmort_back,SizeDeathsIN,
				constMortans,packans,'BACK')
				
				# Print to log
				stringout = 'DoInMortality(): '+str(datetime.datetime.now() -start_time1) + ''
				logMsg(logfHndl,stringout)
				#pdb.set_trace()
				# ---------------------------------
				# Call GetMetrics()
				# ---------------------------------
				# Timing events: start
				start_time1 = datetime.datetime.now()
				GetMetrics(SubpopIN,K,Track_N_Init_pop,Track_K,loci,alleles,gen+1,Track_Ho,Track_Alleles,Track_He,Track_p1,Track_p2,Track_q1,Track_q2,Infected,Residors,Strayers1,Strayers2,Immigrators,PopSizes_Mean,PopSizes_Std,AgeSizes_Mean,AgeSizes_Std,Track_N_Init_age,sizeans,age_size_mean,ClassSizes_Mean,ClassSizes_Std,Track_N_Init_class,packans,RDispersers,IDispersers,xvars_betas,betas_selection,maxfit,minfit,cdevolveans)
				
				# Print to log
				stringout = 'GetMetrics(): '+str(datetime.datetime.now() -start_time1) + ''
				logMsg(logfHndl,stringout)
											
				# Print to log
				stringout = 'End Generation/Year Loop'+str(gen)+': '+str(datetime.datetime.now() -start_timeGen) + '\n'
				logMsg(logfHndl,stringout)
				if multiprocessing.current_process().name == "S0" or multiprocessing.current_process().name == "MainProcess":
					print(stringout)
			
			# End::generation loop
						
			# ------------------------------------------
			# Call DoPostProcess()
			# ------------------------------------------
			#pdb.set_trace()
			# Timing events: start
			start_time1 = datetime.datetime.now()
			
			DoPostProcess(ithmcrundir,loci,alleles,looptime,\
			Track_ToTFemales,Track_ToTMales,Track_BreedFemales,Track_BreedMales,Track_Births,PopDeathsIN,\
			PopDeathsOUT,Track_Alleles,Track_He,Track_Ho,Track_MateDistCD,Track_MateDistCDstd,nthfile,logfHndl,\
			Track_p1,Track_p2,Track_q1,Track_q2,subpopemigration,\
			subpopimmigration,Track_FAvgMate,Track_MAvgMate,Track_FSDMate,Track_MSDMate,\
			SelectionDeathsEmi,SelectionDeathsImm,\
			DisperseDeathsEmi,DisperseDeathsImm,\
			Track_BreedEvents,gridformat,\
			MgSuccess,AdultNoMg,StrSuccess,\
			Track_EggDeaths,Track_K,Track_N_Init_pop,N_Emigration_pop,N_EmiMortality,N_Immigration_pop,N_ImmiMortality,Infected,Residors,Strayers1,Strayers2,Immigrators,PopSizes_Mean,PopSizes_Std,AgeSizes_Mean,AgeSizes_Std,PackingDeathsEmi,PackingDeathsImm,Track_N_Init_age,N_Emigration_age,N_Immigration_age,AgeDeathsOUT,AgeDeathsIN,PackingDeathsEmiAge,PackingDeathsImmAge,Track_MatureCount,Track_ImmatureCount,Track_N_back_age,Track_N_out_age,outputans,gen,Track_CaptureCount_Back,Track_CaptureCount_ClassBack,Track_CaptureCount_Out,Track_CaptureCount_ClassOut,age_size_mean,sizeans,ClassSizes_Mean,ClassSizes_Std,Track_N_Init_class,SizeDeathsOUT,SizeDeathsIN,N_beforePack_pop,N_beforePack_age,SelectionDeaths_Age0s,F_StrayDist,M_StrayDist,F_StrayDist_sd,M_StrayDist_sd,F_ZtrayDist,M_ZtrayDist,F_ZtrayDist_sd,M_ZtrayDist_sd,F_HomeDist,M_HomeDist,F_HomeDist_sd,M_HomeDist_sd,F_EmiDist,M_EmiDist,F_EmiDist_sd,M_EmiDist_sd,Track_AAaaMates,Track_AAAAMates,Track_aaaaMates,Track_AAAaMates,Track_aaAaMates,Track_AaAaMates,Track_ToTYYMales,Track_BreedYYMales,Track_YYSelectionPackDeathsEmi,Track_WildSelectionPackDeathsEmi,Track_YYSelectionPackDeathsImmi,Track_WildSelectionPackDeathsImmi,RDispersers,IDispersers,Track_BirthsYY,Track_KadjEmi,Track_KadjImmi)
			
			# Print to log
			stringout = 'DoPostProcess(): '+str(datetime.datetime.now() -start_time1) + ''
			logMsg(logfHndl,stringout)
			if multiprocessing.current_process().name == "S0" or multiprocessing.current_process().name == "MainProcess":
				print(stringout)
			
			# Print to log
			stringout = 'End Monte Carlo Loop'+str(ithmcrun)+': '+str(datetime.datetime.now() -start_timeMC) + '\n'
			logMsg(logfHndl,stringout)
			if multiprocessing.current_process().name == "S0" or multiprocessing.current_process().name == "MainProcess":
				print(stringout)
			
		# End::Monte Carlo Loop
		
	# End::Batch Loop
